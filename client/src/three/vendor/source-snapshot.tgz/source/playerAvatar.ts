// Player avatar — proper humanoid with named attachment slots that
// wearable atoms can re-parent into.
//
// Slots (THREE.Object3D children of the avatar root):
//   slot.head       — helms, hats, glasses anchor here
//   slot.face       — beards, masks
//   slot.neck       — amulets, scarves, capes hang from this
//   slot.torso      — robes, armor, shirts
//   slot.hand_left  — held items, rings, gloves
//   slot.hand_right — same (default grip is camera grip; this is the body slot)
//   slot.feet       — boots, sandals
//   slot.back       — backpacks, wings, capes
//
// Customization params (all live on PlayerCustomization.state):
//   skinColor        — hex
//   bodyColor        — torso/limbs primary
//   pantsColor       — legs
//   hairStyle        — "short" | "long" | "bun" | "ponytail" | "shaved"
//   hairColor        — hex
//   height           — 1.5 - 2.0 m  (vertical scale)
//   build            — "slim" | "medium" | "stocky"  (torso width scale)
//   eyeColor         — hex (small dot on head)
//
// Pure code, no assets, no bundle increase. Re-renders on demand from
// PlayerCustomization.applyTo(model).

import * as THREE from "three";
// Clay deepening helpers (2026-07-09): jittered roughness + shared thumbprint
// normal map, so the player body reads as the same handmade clay as the world.
import { clayRoughness, getClayNormalMap, clayNormalScale } from "./materialRegistry";
import { applyClayShaderPatch } from "./clayShaderPatch";   // wax-fresnel rim (2026-07-09)
import { bindCharacterRig } from "./characterRigContract";
import type { AtomNode, OpTree } from "../shared/opTree";
import { generateWearable } from "./generators/wearable";

// One of the ten base player models. Regular travellers share the articulated
// humanoid chassis; meme presets add silhouette geometry, and Capybara uses a
// dedicated quadruped chassis.
export type PlayerModelId =
  | "wanderer" | "warden" | "scholar" | "forager" | "nomad"   // semi-regular
  | "capybara" | "goblin" | "golem" | "doge" | "chad";        // meme

export interface PlayerCustomState {
  skinColor: string;
  bodyColor: string;
  pantsColor: string;
  hairStyle: "short" | "long" | "bun" | "ponytail" | "shaved";
  hairColor: string;
  height: number;       // 1.5–2.0 m
  build: "slim" | "medium" | "stocky";
  eyeColor: string;
  /** Which of the ten base models seeds this state. The preset's fields are
   *  applied as a BASE in rebuild(); any explicit customizations override.
   *  Permanent accounts store this in the appearance doc; temp = localStorage. */
  preset?: PlayerModelId;
}

export const DEFAULT_CUSTOM: PlayerCustomState = {
  skinColor:  "#f0d4a8",
  bodyColor:  "#4a3f50",
  pantsColor: "#2a2533",
  hairStyle:  "short",
  hairColor:  "#3a2818",
  height:     1.7,
  build:      "medium",
  eyeColor:   "#3a2818",
  preset:     "wanderer",
};

// ── The ten base player models ─────────────────────────────────────────
// Each preset is a Partial<PlayerCustomState> layered over DEFAULT_CUSTOM.
// `meme: true` flags the joke roster (chooser shows a small badge).
// `gatedGeometry` remains for forward-compatible chooser messaging, but every
// currently shipped model now has its intended base silhouette.
export interface PlayerModelPreset {
  label: string;
  meme: boolean;
  /** True = geometry is a v1 placeholder pending a real asset. */
  gatedGeometry?: boolean;
  /** One-line flavour for the chooser card. */
  blurb?: string;
  state: Partial<PlayerCustomState>;
}

export const PLAYER_MODEL_PRESETS: Record<PlayerModelId, PlayerModelPreset> = {
  // ── 5 semi-regular ──────────────────────────────────────────────────
  wanderer: {
    label: "Wanderer",
    meme: false,
    blurb: "The default traveller.",
    // Exactly DEFAULT_CUSTOM — the baseline everyone starts from.
    state: {
      skinColor: "#f0d4a8", bodyColor: "#4a3f50", pantsColor: "#2a2533",
      hairStyle: "short", hairColor: "#3a2818", height: 1.7, build: "medium",
      eyeColor: "#3a2818",
    },
  },
  warden: {
    label: "Warden",
    meme: false,
    blurb: "Stocky, muted green & brown.",
    state: {
      skinColor: "#d8b48c", bodyColor: "#556b3d", pantsColor: "#4a3a26",
      hairStyle: "short", hairColor: "#2e2114", height: 1.72, build: "stocky",
      eyeColor: "#3a2a16",
    },
  },
  scholar: {
    label: "Scholar",
    meme: false,
    blurb: "Slim, long-haired, deep blue.",
    state: {
      skinColor: "#ecc9a0", bodyColor: "#243a66", pantsColor: "#1b2540",
      hairStyle: "long", hairColor: "#20160c", height: 1.7, build: "slim",
      eyeColor: "#2a3a5a",
    },
  },
  forager: {
    label: "Forager",
    meme: false,
    blurb: "Short, earthy, ponytail.",
    state: {
      skinColor: "#e0b487", bodyColor: "#7a5a34", pantsColor: "#3d4a2a",
      hairStyle: "ponytail", hairColor: "#4a3218", height: 1.58, build: "medium",
      eyeColor: "#3a2a14",
    },
  },
  nomad: {
    label: "Nomad",
    meme: false,
    blurb: "Tall, sand-toned, hooded bun.",
    state: {
      skinColor: "#d9b48f", bodyColor: "#c8b083", pantsColor: "#9a825a",
      hairStyle: "bun", hairColor: "#2a1e12", height: 1.9, build: "medium",
      eyeColor: "#2e2214",
    },
  },
  // ── 5 meme ──────────────────────────────────────────────────────────
  capybara: {
    label: "Capybara",
    meme: true,
    blurb: "Unbothered quadruped traveller.",
    state: {
      skinColor: "#8a6a44", bodyColor: "#6f5334", pantsColor: "#5a4228",
      hairStyle: "shaved", hairColor: "#4a3620", height: 1.55, build: "stocky",
      eyeColor: "#1a120a",
    },
  },
  goblin: {
    label: "Goblin",
    meme: true,
    blurb: "Small, green, up to no good.",
    state: {
      skinColor: "#6f9440", bodyColor: "#3d4a2a", pantsColor: "#2a3018",
      hairStyle: "shaved", hairColor: "#2a3018", height: 1.5, build: "slim",
      eyeColor: "#c8f24b",
    },
  },
  golem: {
    label: "Golem",
    meme: true,
    blurb: "Tall, grey, stony.",
    state: {
      skinColor: "#8f9298", bodyColor: "#6a6d73", pantsColor: "#54575c",
      hairStyle: "shaved", hairColor: "#54575c", height: 2.0, build: "stocky",
      eyeColor: "#2a2c30",
    },
  },
  doge: {
    label: "Doge",
    meme: true,
    blurb: "Such wander. Very tan.",
    state: {
      skinColor: "#e0b25c", bodyColor: "#d9a84e", pantsColor: "#b98a34",
      hairStyle: "short", hairColor: "#8a5e24", height: 1.6, build: "medium",
      eyeColor: "#2a1c0a",
    },
  },
  chad: {
    label: "Chad",
    meme: true,
    blurb: "Maxed. Greyscale. Yes.",
    state: {
      skinColor: "#d8d8d8", bodyColor: "#4a4a4a", pantsColor: "#2a2a2a",
      hairStyle: "short", hairColor: "#3a3a3a", height: 2.0, build: "stocky",
      eyeColor: "#202020",
    },
  },
};

const STORAGE_KEY = "wander.player.customization.v1";
const EQUIPMENT_STORAGE_KEY = "wander.player.equipment.v1";

export type AvatarEquipment = Record<string, AtomNode>;

export class PlayerAvatar {
  /** The visible group; parent it under whatever follows the camera. */
  root: THREE.Group;
  /** Named attachment slots — each is a child Object3D you can reparent into. */
  slots: Record<string, THREE.Object3D> = {};

  state: PlayerCustomState;
  private animArms: THREE.Object3D[] = [];
  private animLegs: THREE.Object3D[] = [];
  private animHead: THREE.Object3D | null = null;
  private quadruped = false;
  private equipment: AvatarEquipment = {};
  private loadSaved = true;

  constructor(initialState?: Partial<PlayerCustomState>, opts: { loadSaved?: boolean } = {}) {
    this.loadSaved = opts.loadSaved !== false;
    this.state = { ...DEFAULT_CUSTOM, ...initialState };
    // Try to load saved state
    try { if (this.loadSaved) {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === "object") {
          this.state = { ...this.state, ...parsed };
        }
      }
    } } catch {}
    try { if (this.loadSaved) {
      const savedEquipment = JSON.parse(localStorage.getItem(EQUIPMENT_STORAGE_KEY) || "{}");
      if (savedEquipment && typeof savedEquipment === "object") {
        for (const [slot, node] of Object.entries(savedEquipment)) {
          if (node && typeof node === "object" && (node as any).op === "atom" && (node as any).kind === "wearable") {
            this.equipment[slot] = node as AtomNode;
          }
        }
      }
    } } catch {}
    this.root = new THREE.Group();
    this.rebuild();
  }

  /** Rebuild the visible mesh from current state. Discards old geometry. */
  rebuild() {
    for (const material of this.root.userData.ponsOwnedMaterials || []) material.dispose();
    this.root.userData.ponsOwnedMaterials = [];
    // Tear down old children
    while (this.root.children.length) {
      const c = this.root.children[0];
      this.root.remove(c);
      disposeRecursive(c);
    }
    this.slots = {};
    this.animArms = [];
    this.animLegs = [];
    this.animHead = null;
    this.quadruped = false;

    // Resolve the effective appearance: the chosen model preset seeds a base,
    // then any explicit customizations in this.state override it. This is what
    // makes the ten models "presets" — pick one and you inherit its palette/
    // build, but every field remains individually editable afterwards.
    // (`preset` itself is control data, not a visual field, so it's stripped.)
    const s = resolveState(this.state);
    // Soft-clay materials (2026-07-08): matte, smooth, no metal — matches the
    // clay world. Replaces the old flat MeshLambert.
    // Clay deepening (2026-07-09): per-material roughness jitter seeded by the
    // colour (stable across rebuilds) + the shared thumbprint normal map, so the
    // body reads as hand-pressed clay instead of one flat matte plastic.
    const clayMat = (c: string) => {
      const hex = new THREE.Color(c).getHex();
      const _m = new THREE.MeshStandardMaterial({
        color: c,
        roughness: clayRoughness(0.92, hex),
        metalness: 0,
        normalMap: getClayNormalMap(),
        normalScale: clayNormalScale(),
        envMapIntensity: 0.5,
      });
      applyClayShaderPatch(_m);   // whisper wax-fresnel rim
      this.root.userData.ponsOwnedMaterials.push(_m);
      return _m;
    };
    const skin = clayMat(s.skinColor);
    const body = clayMat(s.bodyColor);
    const pants = clayMat(s.pantsColor);
    const hair = clayMat(s.hairColor);
    const eye  = new THREE.MeshBasicMaterial({ color: s.eyeColor });
    this.root.userData.ponsOwnedMaterials.push(eye);

    // Build factor controls torso radius + arm offset
    const buildScale = s.build === "slim" ? 0.85 : s.build === "stocky" ? 1.15 : 1.0;

    // Total height: scale all Y positions by (height / 1.7)
    // The base proportions are designed around 1.7m.
    const yScale = s.height / 1.7;

    // Capybara is a true low quadruped, not a palette swap on the humanoid.
    // It still exposes the same attachment-slot contract so hats, packs and
    // held items continue to work through PlayerEntity/customization.
    if (s.preset === "capybara") {
      this.quadruped = true;
      const q = new THREE.Group();
      const qScale = s.height / 1.55;
      q.scale.setScalar(qScale);
      this.root.add(q);
      const addSlot = (name: string, x: number, y: number, z: number) => {
        const slot = new THREE.Object3D();
        slot.position.set(x, y, z); q.add(slot); this.slots[name] = slot;
      };
      const bodyMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.29, 0.66, 6, 14), body);
      bodyMesh.rotation.x = Math.PI / 2;
      bodyMesh.position.set(0, 0.61, -0.04);
      bodyMesh.scale.x = 1.08 * buildScale;
      bodyMesh.castShadow = true; q.add(bodyMesh);
      const chest = new THREE.Mesh(new THREE.SphereGeometry(0.31, 16, 12), body);
      chest.position.set(0, 0.64, 0.30); chest.scale.set(1.05 * buildScale, 1, 0.95);
      chest.castShadow = true; q.add(chest);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 16, 12), body);
      head.position.set(0, 0.74, 0.57); head.scale.set(1.0, 0.92, 1.18);
      head.castShadow = true; q.add(head);
      this.animHead = head;
      const muzzle = new THREE.Mesh(new THREE.SphereGeometry(0.17, 14, 10), skin);
      muzzle.position.set(0, 0.69, 0.82); muzzle.scale.set(1.15, 0.78, 1.05);
      muzzle.castShadow = true; q.add(muzzle);
      for (const side of [-1, 1]) {
        const ear = new THREE.Mesh(new THREE.SphereGeometry(0.075, 10, 8), hair);
        ear.position.set(side * 0.18, 0.94, 0.50); ear.scale.set(0.9, 1.15, 0.65); q.add(ear);
        const e = new THREE.Mesh(new THREE.SphereGeometry(0.027, 8, 6), eye);
        e.position.set(side * 0.105, 0.79, 0.79); q.add(e);
        const nostril = new THREE.Mesh(new THREE.SphereGeometry(0.015, 7, 5), eye);
        nostril.position.set(side * 0.055, 0.72, 0.965); q.add(nostril);
      }
      for (const x of [-0.20, 0.20]) for (const z of [-0.30, 0.30]) {
        const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.28, 4, 9), body);
        leg.position.set(x * buildScale, 0.27, z); leg.castShadow = true; q.add(leg);
        this.animLegs.push(leg);
        const paw = new THREE.Mesh(new THREE.SphereGeometry(0.085, 9, 7), hair);
        paw.position.set(x * buildScale, 0.07, z + 0.035); paw.scale.set(1, 0.62, 1.2); q.add(paw);
      }
      const tail = new THREE.Mesh(new THREE.SphereGeometry(0.055, 9, 7), hair);
      tail.position.set(0, 0.55, -0.63); tail.scale.set(1, 0.8, 0.65); q.add(tail);
      addSlot("torso", 0, 0.64, 0);
      addSlot("back", 0, 0.94, -0.06);
      addSlot("neck", 0, 0.82, 0.36);
      addSlot("head", 0, 1.02, 0.56);
      addSlot("face", 0, 0.76, 0.91);
      addSlot("hand_left", -0.20, 0.16, 0.34);
      addSlot("hand_right", 0.20, 0.16, 0.34);
      addSlot("feet", 0, 0.06, 0.02);
      this.attachEquipment();
      bindCharacterRig(this.root, "player", { head: this.animHead, arms: this.animArms, legs: this.animLegs, slots: this.slots });
      return;
    }

    // Legs (waist down to feet, feet at y=0)
    for (const side of [-1, 1]) {
      const leg = new THREE.Mesh(
        new THREE.CylinderGeometry(0.13 * buildScale, 0.12 * buildScale, 0.85 * yScale, 10),
        pants,
      );
      leg.position.set(side * 0.13 * buildScale, 0.42 * yScale, 0);
      leg.castShadow = true;
      this.root.add(leg);
      this.animLegs.push(leg);
    }

    // Torso
    const torso = new THREE.Mesh(
      new THREE.CylinderGeometry(0.30 * buildScale, 0.34 * buildScale, 0.65 * yScale, 12),
      body,
    );
    torso.position.set(0, 1.17 * yScale, 0);
    torso.castShadow = true;
    this.root.add(torso);

    // Slot: torso (matches torso center)
    const slotTorso = new THREE.Object3D();
    slotTorso.position.copy(torso.position);
    this.root.add(slotTorso);
    this.slots["torso"] = slotTorso;

    // Slot: back (behind torso)
    const slotBack = new THREE.Object3D();
    slotBack.position.set(0, 1.17 * yScale, -0.2);
    this.root.add(slotBack);
    this.slots["back"] = slotBack;

    // Arms — a proper shoulder→arm→hand chain in a pivot group per side.
    // The group pivots at the shoulder and splays slightly outward so the arms
    // read as attached and don't clip the torso/legs. Hand slot lives inside
    // the group, so held items follow the arm.
    const shoulderY = 1.44 * yScale;
    const armLen = 0.60 * yScale;
    for (const side of [-1, 1]) {
      const armGroup = new THREE.Group();
      armGroup.position.set(side * (0.30 * buildScale + 0.04), shoulderY, 0);
      armGroup.rotation.z = side * 0.16;   // outward splay from the shoulder pivot
      this.root.add(armGroup);
      this.animArms.push(armGroup);

      // Shoulder joint (rounds the torso→arm junction)
      const shoulder = new THREE.Mesh(new THREE.SphereGeometry(0.095 * buildScale, 12, 10), body);
      shoulder.castShadow = true;
      armGroup.add(shoulder);

      // Upper arm — tapered capsule hanging from the shoulder
      const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.072 * buildScale, armLen, 4, 10), body);
      arm.position.set(0, -armLen * 0.5 - 0.04, 0);
      arm.castShadow = true;
      armGroup.add(arm);

      // Hand — a rounded clay mitt at the end of the arm
      const handLocalY = -armLen - 0.08;
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.078 * buildScale, 10, 8), skin);
      hand.position.set(0, handLocalY, 0);
      hand.scale.set(1, 0.85, 1);
      hand.castShadow = true;
      armGroup.add(hand);

      // Hand slot (child of the arm group → tracks arm pose)
      const slotHand = new THREE.Object3D();
      slotHand.position.set(0, handLocalY, 0.03);
      armGroup.add(slotHand);
      this.slots[side === -1 ? "hand_left" : "hand_right"] = slotHand;
    }

    // Neck
    const neck = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.09, 0.08 * yScale, 8),
      skin,
    );
    neck.position.set(0, 1.55 * yScale, 0);
    this.root.add(neck);
    const slotNeck = new THREE.Object3D();
    slotNeck.position.set(0, 1.55 * yScale, 0.04);
    this.root.add(slotNeck);
    this.slots["neck"] = slotNeck;

    // Head (sphere)
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.18 * yScale, 16, 12),
      skin,
    );
    head.position.set(0, 1.74 * yScale, 0);
    head.castShadow = true;
    this.root.add(head);
    this.animHead = head;

    // Eyes (two small dots on the front of the head)
    for (const side of [-1, 1]) {
      const e = new THREE.Mesh(
        new THREE.SphereGeometry(0.025 * yScale, 8, 6),
        eye,
      );
      e.position.set(side * 0.06, 1.77 * yScale, 0.16 * yScale);
      this.root.add(e);
    }

    // Nose — a small clay nub for a bit more character
    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.03 * yScale, 8, 6), skin);
    nose.position.set(0, 1.73 * yScale, 0.18 * yScale);
    nose.scale.set(1, 0.8, 1.1);
    this.root.add(nose);

    // Face slot (just in front of eyes — for masks/glasses)
    const slotFace = new THREE.Object3D();
    slotFace.position.set(0, 1.76 * yScale, 0.18);
    this.root.add(slotFace);
    this.slots["face"] = slotFace;

    // Hair (depends on style)
    if (s.hairStyle !== "shaved") {
      const hairTop = new THREE.Mesh(
        new THREE.SphereGeometry(0.20 * yScale, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.55),
        hair,
      );
      hairTop.position.set(0, 1.78 * yScale, 0);
      hairTop.castShadow = true;
      this.root.add(hairTop);
      if (s.hairStyle === "long") {
        const back = new THREE.Mesh(
          new THREE.BoxGeometry(0.34 * yScale, 0.4 * yScale, 0.08),
          hair,
        );
        back.position.set(0, 1.55 * yScale, -0.13);
        this.root.add(back);
      } else if (s.hairStyle === "ponytail") {
        const tail = new THREE.Mesh(
          new THREE.CylinderGeometry(0.06 * yScale, 0.04 * yScale, 0.35 * yScale, 8),
          hair,
        );
        tail.position.set(0, 1.55 * yScale, -0.12);
        this.root.add(tail);
      } else if (s.hairStyle === "bun") {
        const bun = new THREE.Mesh(
          new THREE.SphereGeometry(0.09 * yScale, 12, 10),
          hair,
        );
        bun.position.set(0, 1.96 * yScale, -0.06);
        this.root.add(bun);
      }
    }

    // Slot: head (top of head, for hats/helms)
    const slotHead = new THREE.Object3D();
    slotHead.position.set(0, 1.92 * yScale, 0);
    this.root.add(slotHead);
    this.slots["head"] = slotHead;

    // Slot: feet (each foot)
    for (const side of [-1, 1]) {
      const foot = new THREE.Mesh(
        new THREE.BoxGeometry(0.12, 0.08, 0.22),
        pants,
      );
      foot.position.set(side * 0.13 * buildScale, 0.04, 0.05);
      foot.castShadow = true;
      this.root.add(foot);
    }
    const slotFeet = new THREE.Object3D();
    slotFeet.position.set(0, 0.04, 0.05);
    this.root.add(slotFeet);
    this.slots["feet"] = slotFeet;

    // Meme presets need a silhouette, not only a palette. These lightweight
    // clay additions keep the shared wearable/animation chassis intact.
    if (s.preset === "goblin") {
      for (const side of [-1, 1]) {
        const ear = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.34, 10), skin);
        ear.position.set(side * 0.30, 1.77 * yScale, 0);
        ear.rotation.z = side * -Math.PI / 2; ear.castShadow = true; this.root.add(ear);
      }
      nose.scale.set(1.2, 0.9, 2.2);
      nose.position.z = 0.215 * yScale;
    } else if (s.preset === "doge") {
      for (const side of [-1, 1]) {
        const ear = new THREE.Mesh(new THREE.ConeGeometry(0.095, 0.27, 10), hair);
        ear.position.set(side * 0.12, 2.00 * yScale, -0.01);
        ear.rotation.z = side * -0.12; ear.castShadow = true; this.root.add(ear);
      }
      const muzzle = new THREE.Mesh(new THREE.SphereGeometry(0.085 * yScale, 10, 8), skin);
      muzzle.position.set(0, 1.70 * yScale, 0.205 * yScale);
      muzzle.scale.set(1.25, 0.75, 1.15); muzzle.castShadow = true; this.root.add(muzzle);
      const snout = new THREE.Mesh(new THREE.SphereGeometry(0.027 * yScale, 8, 6), eye);
      snout.position.set(0, 1.72 * yScale, 0.292 * yScale); this.root.add(snout);
    } else if (s.preset === "golem") {
      for (const side of [-1, 1]) {
        const shoulderRock = new THREE.Mesh(new THREE.DodecahedronGeometry(0.18 * buildScale, 0), body);
        shoulderRock.position.set(side * 0.42 * buildScale, 1.43 * yScale, -0.02);
        shoulderRock.rotation.set(side * 0.2, 0.25, side * 0.35);
        shoulderRock.castShadow = true; this.root.add(shoulderRock);
      }
      head.scale.set(1.15, 0.95, 1.0);
      const brow = new THREE.Mesh(new THREE.BoxGeometry(0.30, 0.055, 0.06), hair);
      brow.position.set(0, 1.82 * yScale, 0.16 * yScale); brow.castShadow = true; this.root.add(brow);
    } else if (s.preset === "chad") {
      head.scale.set(1.12, 1.02, 1.0);
      const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.31 * yScale, 0.16 * yScale, 0.25 * yScale), skin);
      jaw.position.set(0, 1.64 * yScale, 0.035); jaw.castShadow = true; this.root.add(jaw);
      const chin = new THREE.Mesh(new THREE.BoxGeometry(0.17 * yScale, 0.08 * yScale, 0.07), skin);
      chin.position.set(0, 1.57 * yScale, 0.15); chin.castShadow = true; this.root.add(chin);
    }
    this.attachEquipment();
    bindCharacterRig(this.root, "player", { head: this.animHead, arms: this.animArms, legs: this.animLegs, slots: this.slots });
  }

  private attachEquipment(): void {
    for (const [slot, node] of Object.entries(this.equipment)) {
      const target = this.slots[slot];
      if (!target) continue;
      try {
        const visual = generateWearable(node);
        visual.name = `equipped:${slot}:${String(node.params?.profile || "wearable")}`;
        visual.userData.equippedWearable = true;
        target.add(visual);
      } catch (e) { console.warn(`[avatar] wearable failed for ${slot}:`, e); }
    }
  }

  private saveEquipment(): void {
    if (!this.loadSaved) return;
    try { localStorage.setItem(EQUIPMENT_STORAGE_KEY, JSON.stringify(this.equipment)); } catch {}
  }

  /** Equip one wearable atom into its authored attachment slot. */
  equipWearable(node: AtomNode): string | null {
    if (!node || node.kind !== "wearable") return null;
    const slot = String(node.params?.attach_slot || this.slotForProfile(String(node.params?.profile || "")));
    if (!this.slots[slot] && !["head", "face", "neck", "torso", "back", "hand_left", "hand_right", "feet"].includes(slot)) return null;
    this.equipment[slot] = JSON.parse(JSON.stringify(node));
    this.saveEquipment(); this.rebuild();
    return slot;
  }

  /** Replace the current outfit with every wearable child in an outfit tree. */
  equipOutfit(tree: OpTree): number {
    const root: any = tree?.root;
    if (!root || root.op !== "composer" || root.kind !== "outfit" || !Array.isArray(root.children)) return 0;
    const next: AvatarEquipment = {};
    for (const child of root.children) {
      if (child?.op !== "atom" || child.kind !== "wearable") continue;
      const slot = String(child.params?.attach_slot || this.slotForProfile(String(child.params?.profile || "")));
      if (slot) next[slot] = JSON.parse(JSON.stringify(child));
    }
    this.equipment = next;
    this.saveEquipment(); this.rebuild();
    return Object.keys(next).length;
  }

  unequip(slot: string): AtomNode | null {
    const node = this.equipment[slot];
    if (!node) return null;
    delete this.equipment[slot];
    this.saveEquipment(); this.rebuild();
    return JSON.parse(JSON.stringify(node));
  }

  clearEquipment(): void {
    this.equipment = {};
    this.saveEquipment(); this.rebuild();
  }

  equipmentSnapshot(): AvatarEquipment {
    return JSON.parse(JSON.stringify(this.equipment));
  }

  setEquipment(equipment: AvatarEquipment): void {
    this.equipment = JSON.parse(JSON.stringify(equipment || {}));
    this.saveEquipment(); this.rebuild();
  }

  private slotForProfile(profile: string): string {
    return ({
      glasses: "face", mask: "face", helm: "head", head: "head", hat: "head",
      boots: "feet", feet: "feet", ring: "hand_right", amulet: "neck", scarf: "neck",
      cape: "back", backpack: "back", cloak: "torso", robe: "torso", armor: "torso",
      shirt: "torso", jacket: "torso", tunic: "torso", skirt: "torso", belt: "torso",
    } as Record<string, string>)[profile] || "torso";
  }

  /** Drive the local third-person chassis from the same movement truth used by
   * controls. Peers/NPCs already animate; without this the player's own improved
   * model froze whenever O switched to third person. */
  animate(timeSeconds: number, moving: boolean, speed = 1): void {
    if (!this.root.visible) return;
    const rate = (this.quadruped ? 7.0 : 6.2) * Math.max(0.6, speed);
    const amp = this.quadruped ? 0.36 : 0.58;
    const phase = timeSeconds * rate;
    for (let i = 0; i < this.animLegs.length; i++) {
      const pairPhase = this.quadruped ? (i === 0 || i === 3 ? 0 : Math.PI) : (i % 2) * Math.PI;
      const target = moving ? Math.sin(phase + pairPhase) * amp : 0;
      this.animLegs[i].rotation.x += (target - this.animLegs[i].rotation.x) * 0.24;
    }
    for (let i = 0; i < this.animArms.length; i++) {
      const target = moving ? Math.sin(phase + (i % 2) * Math.PI + Math.PI) * amp * 0.72 : 0;
      this.animArms[i].rotation.x += (target - this.animArms[i].rotation.x) * 0.24;
    }
    if (this.animHead) {
      const target = moving ? Math.sin(phase * 2) * 0.025 : Math.sin(timeSeconds * 0.7) * 0.045;
      this.animHead.rotation.y += (target - this.animHead.rotation.y) * 0.08;
    }
  }

  /** Persist current state to localStorage. */
  save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch {}
  }

  /** Apply a patch + rebuild + save. */
  update(patch: Partial<PlayerCustomState>) {
    Object.assign(this.state, patch);
    this.rebuild();
    this.save();
  }

  /**
   * Switch to one of the ten base models: bakes the preset's palette/build
   * into `state` (so later per-field edits override it) AND stamps `preset`
   * so the choice round-trips through the appearance doc / localStorage.
   * Equivalent to `update({ ...PLAYER_MODEL_PRESETS[id].state, preset: id })`.
   */
  setModel(id: PlayerModelId) {
    const p = PLAYER_MODEL_PRESETS[id];
    if (!p) return;
    this.update({ ...p.state, preset: id });
  }
}

// Fields the renderer actually reads (everything on PlayerCustomState except
// the `preset` control tag). Kept explicit so resolveState's overlay is total.
const VISUAL_KEYS: (keyof PlayerCustomState)[] = [
  "skinColor", "bodyColor", "pantsColor", "hairStyle",
  "hairColor", "height", "build", "eyeColor",
];

/**
 * Effective visual state = the model preset as a base, with any explicit,
 * defined visual fields in `state` layered on top. Returns a fully-populated
 * PlayerCustomState (preset stripped) safe to render.
 *
 * In normal use the chooser BAKES a preset's fields into `state` at pick-time
 * (`avatar.update(PLAYER_MODEL_PRESETS[id].state)`), so `state` already carries
 * the chosen palette and later per-field edits simply overwrite it. This helper
 * additionally guarantees correctness when `state` is a bare `{ preset }` (e.g.
 * an appearance doc that only stored the model id) by falling back to the
 * preset's values for any field that is missing.
 */
export function resolveState(state: PlayerCustomState): PlayerCustomState {
  const preset = state.preset ? PLAYER_MODEL_PRESETS[state.preset] : undefined;
  const base: PlayerCustomState = preset
    ? { ...DEFAULT_CUSTOM, ...preset.state }
    : { ...DEFAULT_CUSTOM };
  for (const k of VISUAL_KEYS) {
    const v = state[k];
    if (v !== undefined && v !== null) (base as Record<string, unknown>)[k] = v;
  }
  base.preset = state.preset;
  return base;
}

function disposeRecursive(obj: THREE.Object3D) {
  obj.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.geometry) m.geometry.dispose();
    if (m.material) {
      if (Array.isArray(m.material)) m.material.forEach((mat) => mat.dispose());
      else (m.material as THREE.Material).dispose();
    }
  });
}

// ── Character editor UI (used by inventory's Character tab) ────────────

export interface CharacterEditorOpts {
  avatar: PlayerAvatar;
  hud?: (msg: string) => void;
  /** Called after any state change so the host can mirror changes
   *  (e.g. to multiplayer presence). */
  onChange?: (state: PlayerCustomState) => void;
}

export function buildCharacterEditor(opts: CharacterEditorOpts): HTMLElement {
  const a = opts.avatar;
  const root = document.createElement("div");
  root.style.cssText = `
    display: grid; grid-template-columns: 220px 1fr;
    gap: 1.0rem;
    font-family: 'Fredoka', sans-serif; color: #3a2818;
  `;

  // Left: live preview canvas (mini Three.js renderer of the avatar)
  const previewWrap = document.createElement("div");
  previewWrap.style.cssText = `
    background: #fff7e0;
    border: 2px solid #3a2818; border-radius: 8px;
    box-shadow: 3px 3px 0 #3a2818;
    aspect-ratio: 1 / 1.4;
    position: relative;
  `;
  const previewCanvas = document.createElement("canvas");
  previewCanvas.style.cssText = "width:100%;height:100%;display:block";
  previewWrap.appendChild(previewCanvas);
  root.appendChild(previewWrap);

  // Right: editor controls
  const controls = document.createElement("div");
  controls.style.cssText = "display:flex;flex-direction:column;gap:0.55rem";

  // Color picker helper
  const colorPicker = (label: string, key: keyof PlayerCustomState) => {
    const row = document.createElement("div");
    row.style.cssText = "display:flex;justify-content:space-between;align-items:center;gap:0.5rem";
    const lbl = document.createElement("span");
    lbl.textContent = label;
    lbl.style.cssText = "font-style:italic;font-family:'EB Garamond',Georgia,serif";
    const input = document.createElement("input");
    input.type = "color";
    input.value = String(a.state[key]);
    input.style.cssText = "width:48px;height:32px;border:2px solid #3a2818;border-radius:4px;cursor:pointer";
    input.addEventListener("input", () => {
      a.update({ [key]: input.value } as Partial<PlayerCustomState>);
      drawPreview();
      if (opts.onChange) opts.onChange(a.state);
    });
    row.appendChild(lbl); row.appendChild(input);
    return row;
  };

  // Slider helper
  const sliderControl = (label: string, key: "height", min: number, max: number, step: number) => {
    const row = document.createElement("div");
    row.style.cssText = "display:flex;flex-direction:column;gap:0.2rem";
    const head = document.createElement("div");
    head.style.cssText = "display:flex;justify-content:space-between;font-size:0.85rem";
    const lbl = document.createElement("span");
    lbl.textContent = label;
    lbl.style.cssText = "font-style:italic;font-family:'EB Garamond',Georgia,serif";
    const valEl = document.createElement("span");
    valEl.textContent = String(a.state[key]);
    valEl.style.cssText = "font-weight:600";
    head.appendChild(lbl); head.appendChild(valEl);
    const range = document.createElement("input");
    range.type = "range";
    range.min = String(min); range.max = String(max); range.step = String(step);
    range.value = String(a.state[key]);
    range.style.cssText = "width:100%;accent-color:#c89540";
    range.addEventListener("input", () => {
      const v = parseFloat(range.value);
      valEl.textContent = v.toFixed(2);
      a.update({ [key]: v } as Partial<PlayerCustomState>);
      drawPreview();
      if (opts.onChange) opts.onChange(a.state);
    });
    row.appendChild(head); row.appendChild(range);
    return row;
  };

  // Select helper
  const selectControl = <K extends keyof PlayerCustomState>(label: string, key: K, options: string[]) => {
    const row = document.createElement("div");
    row.style.cssText = "display:flex;justify-content:space-between;align-items:center";
    const lbl = document.createElement("span");
    lbl.textContent = label;
    lbl.style.cssText = "font-style:italic;font-family:'EB Garamond',Georgia,serif";
    const sel = document.createElement("select");
    sel.style.cssText = "padding:0.2rem 0.4rem;border:2px solid #3a2818;border-radius:4px;font-family:'Fredoka',sans-serif;background:#fff7e0";
    for (const opt of options) {
      const o = document.createElement("option");
      o.value = opt; o.textContent = opt;
      if (a.state[key] === opt) o.selected = true;
      sel.appendChild(o);
    }
    sel.addEventListener("change", () => {
      a.update({ [key]: sel.value } as Partial<PlayerCustomState>);
      drawPreview();
      if (opts.onChange) opts.onChange(a.state);
    });
    row.appendChild(lbl); row.appendChild(sel);
    return row;
  };

  const modelRow = document.createElement("div");
  modelRow.style.cssText = "display:flex;justify-content:space-between;align-items:center;gap:.5rem;padding-bottom:.45rem;border-bottom:2px dotted rgba(58,40,24,.25)";
  const modelLabel = document.createElement("span"); modelLabel.textContent = "Base model"; modelLabel.style.cssText = "font:italic 1rem 'EB Garamond',serif";
  const modelSelect = document.createElement("select"); modelSelect.setAttribute("aria-label", "Base model");
  modelSelect.style.cssText = "padding:.25rem .45rem;border:2px solid #3a2818;border-radius:4px;font-family:'Fredoka',sans-serif;background:#fff7e0";
  for (const [id, preset] of Object.entries(PLAYER_MODEL_PRESETS)) {
    const option = document.createElement("option"); option.value = id; option.textContent = preset.label; option.selected = a.state.preset === id; modelSelect.appendChild(option);
  }
  modelSelect.addEventListener("change", () => {
    a.setModel(modelSelect.value as PlayerModelId);
    drawPreview(); opts.onChange?.(a.state);
  });
  modelRow.append(modelLabel, modelSelect); controls.appendChild(modelRow);

  controls.appendChild(colorPicker("Skin", "skinColor"));
  controls.appendChild(colorPicker("Body / robe", "bodyColor"));
  controls.appendChild(colorPicker("Pants", "pantsColor"));
  controls.appendChild(colorPicker("Hair", "hairColor"));
  controls.appendChild(colorPicker("Eyes", "eyeColor"));
  controls.appendChild(selectControl("Hair style", "hairStyle", ["short", "long", "bun", "ponytail", "shaved"]));
  controls.appendChild(selectControl("Build", "build", ["slim", "medium", "stocky"]));
  controls.appendChild(sliderControl("Height (m)", "height", 1.5, 2.0, 0.05));

  const resetBtn = document.createElement("button");
  resetBtn.textContent = "Reset to default";
  resetBtn.style.cssText = `
    background: #fff7e0; border: 2px solid #3a2818; color: #3a2818;
    padding: 0.4rem 0.8rem; font-family: 'Fredoka', sans-serif; font-weight: 600;
    border-radius: 6px; cursor: pointer; box-shadow: 2px 2px 0 #3a2818;
    margin-top: 0.6rem; align-self: flex-start;
  `;
  resetBtn.addEventListener("click", () => {
    a.update({ ...DEFAULT_CUSTOM });
    drawPreview();
    opts.onChange?.(a.state);
    // Refresh inputs by tearing down + re-mounting
    if (opts.hud) opts.hud("character reset to default");
    const parent = root.parentNode;
    if (parent) {
      parent.removeChild(root);
      parent.appendChild(buildCharacterEditor(opts));
    }
  });
  controls.appendChild(resetBtn);

  root.appendChild(controls);

  // ── Preview renderer ─────────────────────────────────────────────
  // Lightweight: own scene + own camera + own renderer rendering only the
  // avatar. Renders once on each input change; not in the main animation
  // loop (the modal isn't always open).
  const previewScene = new THREE.Scene();
  previewScene.background = new THREE.Color(0xfff7e0);
  const previewCamera = new THREE.PerspectiveCamera(35, 1 / 1.4, 0.1, 50);
  previewCamera.position.set(0, 1.0, 3.5);
  previewCamera.lookAt(0, 1.0, 0);
  const previewLight = new THREE.HemisphereLight(0xfff8e4, 0xa68870, 1.4);
  previewScene.add(previewLight);
  const previewSun = new THREE.DirectionalLight(0xfff0d8, 1.0);
  previewSun.position.set(2, 4, 3);
  previewScene.add(previewSun);

  const previewAvatar = new PlayerAvatar({ ...a.state });
  previewScene.add(previewAvatar.root);

  let previewRenderer: THREE.WebGLRenderer | null = null;
  function ensureRenderer() {
    if (previewRenderer) return;
    const w = previewCanvas.clientWidth || 200;
    const h = previewCanvas.clientHeight || 280;
    previewRenderer = new THREE.WebGLRenderer({ canvas: previewCanvas, antialias: true, alpha: false });
    previewRenderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    previewRenderer.setSize(w, h, false);
    previewCamera.aspect = w / h;
    previewCamera.updateProjectionMatrix();
  }

  let rotateRaf = 0;
  function drawPreview() {
    ensureRenderer();
    if (!previewRenderer) return;
    // sync preview avatar to current state
    previewAvatar.state = { ...a.state };
    previewAvatar.rebuild();
    previewRenderer.render(previewScene, previewCamera);
  }

  // Slow rotation for personality
  function tickRotate() {
    if (!root.isConnected) {
      cancelAnimationFrame(rotateRaf);
      if (previewRenderer) previewRenderer.dispose();
      return;
    }
    previewAvatar.root.rotation.y += 0.005;
    if (previewRenderer) previewRenderer.render(previewScene, previewCamera);
    rotateRaf = requestAnimationFrame(tickRotate);
  }

  // Defer first draw so the canvas has a real size
  setTimeout(() => { drawPreview(); tickRotate(); }, 50);

  return root;
}
