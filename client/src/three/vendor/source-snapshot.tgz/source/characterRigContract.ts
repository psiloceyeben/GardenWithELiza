import * as THREE from "three";

export type CharacterMotionState = "idle" | "walk" | "run" | "talk" | "attack" | "damage" | "dead";

export interface CharacterRigContract {
  version: 1;
  role: "player" | "peer" | "npc" | "meme";
  root: THREE.Object3D;
  head?: THREE.Object3D;
  arms: THREE.Object3D[];
  legs: THREE.Object3D[];
  handLeft: THREE.Object3D;
  handRight: THREE.Object3D;
  state: CharacterMotionState;
  detailMeshes: THREE.Object3D[];
  damageUntil: number;
  groundOffset: number;
}

const registered = new Set<THREE.Object3D>();
let lastLodMs = 0;

function asNodes(v: unknown): THREE.Object3D[] {
  return Array.isArray(v) ? v.filter((x): x is THREE.Object3D => !!x && (x as any).isObject3D) : [];
}

function makeHandSocket(parent: THREE.Object3D | undefined, fallback: THREE.Object3D, side: number): THREE.Object3D {
  const socket = new THREE.Object3D();
  socket.name = side < 0 ? "slot.hand_left" : "slot.hand_right";
  socket.position.set(0, -0.48, 0.08);
  (parent || fallback).add(socket);
  return socket;
}

/** Normalize local players, peers, NPCs, and meme species onto one rig contract. */
export function bindCharacterRig(
  root: THREE.Object3D,
  role: CharacterRigContract["role"],
  explicit?: { head?: THREE.Object3D | null; arms?: THREE.Object3D[]; legs?: THREE.Object3D[]; slots?: Record<string, THREE.Object3D> },
): CharacterRigContract {
  const source = (root.userData as any).characterRig || (root.userData as any).rig || {};
  const arms = explicit?.arms || asNodes(source.arms || source.armPivots);
  const legs = explicit?.legs || asNodes(source.legs || source.legPivots);
  const head = explicit?.head || source.head || source.headPivot;
  const slots = explicit?.slots || (root.userData as any).characterSlots || {};
  const handLeft = slots.hand_left || source.handLeft || source.leftHand || makeHandSocket(arms[0], root, -1);
  const handRight = slots.hand_right || source.handRight || source.rightHand || makeHandSocket(arms[1] || arms[0], root, 1);

  const detailMeshes: THREE.Object3D[] = [];
  const box = new THREE.Box3(); const size = new THREE.Vector3();
  root.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    box.setFromObject(mesh).getSize(size);
    if (Math.max(size.x, size.y, size.z) < 0.16 || (o.userData as any).isMemeFace) detailMeshes.push(o);
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    for (const m of mats) {
      if (!m || (m as any).isMeshBasicMaterial) continue;
      if (typeof (m as any).roughness === "number") (m as any).roughness = Math.max(0.82, (m as any).roughness);
      if (typeof (m as any).metalness === "number") (m as any).metalness = 0;
    }
  });
  const bounds = new THREE.Box3().setFromObject(root);
  const groundOffset = Number.isFinite(bounds.min.y) ? -bounds.min.y : 0;
  const contract: CharacterRigContract = {
    version: 1, role, root, head: head || undefined, arms, legs, handLeft, handRight,
    state: "idle", detailMeshes, damageUntil: 0, groundOffset,
  };
  (root.userData as any).characterRig = { arms, legs, head, handLeft, handRight };
  (root.userData as any).characterContract = contract;
  (root.userData as any).characterSlots = { ...slots, hand_left: handLeft, hand_right: handRight };
  registered.add(root);
  return contract;
}

export function characterContract(root: THREE.Object3D): CharacterRigContract | null {
  return ((root.userData as any).characterContract as CharacterRigContract) || null;
}

export function setCharacterState(root: THREE.Object3D, state: CharacterMotionState): void {
  const c = characterContract(root);
  if (c) c.state = state;
}

export function reactCharacterDamage(root: THREE.Object3D): void {
  const c = characterContract(root);
  if (!c) return;
  c.state = "damage";
  c.damageUntil = performance.now() + 320;
  root.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    for (const m of (Array.isArray(mesh.material) ? mesh.material : [mesh.material])) {
      if ((m as any)?.emissive instanceof THREE.Color) {
        (m as any).emissive.set(0xff4538); (m as any).emissiveIntensity = 0.75;
      }
    }
  });
}

/** Central distance LOD + talk/damage pose tick for every bound character. */
export function tickCharacterContracts(viewer: THREE.Object3D, nowMs = performance.now()): void {
  const viewerPos = new THREE.Vector3(); viewer.getWorldPosition(viewerPos);
  const world = new THREE.Vector3();
  const doLod = nowMs - lastLodMs >= 200;
  if (doLod) lastLodMs = nowMs;
  for (const root of [...registered]) {
    if (!root.parent) { registered.delete(root); continue; }
    const c = characterContract(root); if (!c) continue;
    if (c.damageUntil && nowMs >= c.damageUntil) {
      c.damageUntil = 0; c.state = "idle";
      root.traverse((o) => {
        const mesh = o as THREE.Mesh; if (!mesh.isMesh) return;
        for (const m of (Array.isArray(mesh.material) ? mesh.material : [mesh.material])) {
          if ((m as any)?.emissive instanceof THREE.Color) { (m as any).emissive.set(0); (m as any).emissiveIntensity = 0; }
        }
      });
    }
    const t = nowMs / 1000;
    if (c.state === "talk") {
      if (c.head) c.head.rotation.y = Math.sin(t * 5) * 0.14;
      c.arms.forEach((arm, i) => { arm.rotation.x = Math.sin(t * 6 + i * 2.2) * 0.25; });
    } else if (c.state === "damage" && c.head) {
      c.head.rotation.z = Math.sin(t * 45) * 0.12;
    }
    if (!doLod) continue;
    root.getWorldPosition(world);
    const distance = viewerPos.distanceTo(world);
    root.visible = distance < 220;
    const showDetail = distance < 55;
    for (const mesh of c.detailMeshes) mesh.visible = showDetail;
    (root.userData as any).characterLod = distance < 28 ? "near" : distance < 90 ? "mid" : "far";
  }
}
