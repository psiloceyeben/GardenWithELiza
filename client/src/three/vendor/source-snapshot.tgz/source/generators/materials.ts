// Modifier-aware material resolution.
//
// v6.25.5: TOON / WARM-CARTOON BASELINE.
// Previously the resolver returned MeshStandardMaterial — physically correct
// shading, but visually generic. Combined with the depth-edge outline shader,
// that produced a "demo-grade Three.js scene" look, not the cohesive
// cartoon-builder aesthetic the launch needs.
//
// This version:
//   1. Returns MeshToonMaterial by default. Toon materials posterize lighting
//      into discrete bands (2-4 stops), which combined with the depth-edge
//      outline pass produces an immediately readable cartoon silhouette.
//   2. Bumps saturation +12% on most palette entries so the world reads warm.
//      Marble stays cream, concrete warms to a sandy gray, wood deepens.
//   3. Adds a 4-stop gradient ramp for the toon shading. The shared ramp
//      texture is generated once on first call and reused — no per-material
//      allocation cost.
//   4. Glass and metals stay PhysicalMaterial / StandardMaterial because
//      toon shading on glass kills the transparency cue and toon on metal
//      destroys the reflection cue. Cartoon look applies to opaque
//      construction materials only.
//   5. Procedural texture hints (UV grain on wood, speckle on stone) are
//      not yet wired — that lands in v6.25.6 when we add the texture
//      atlas. The palette + toon + outline shader together already get us
//      ~80% of the way to the warm cartoon look.

import * as THREE from "three";
// single soft-clay switch (2026-07-08) + clay deepening helpers (2026-07-09):
// jittered roughness + shared thumbprint normal map, so op-tree content atoms
// read as the same handmade clay as the rest of the world.
import { CLAY_MODE, clayRoughness, getClayNormalMap, clayNormalScale } from "../materialRegistry";
import { applyClayShaderPatch } from "../clayShaderPatch";   // wax-fresnel rim (2026-07-09)

interface PaletteEntry {
  color: number;
  roughness: number;
  metalness: number;
  /** If true, use MeshToonMaterial. False = MeshStandardMaterial (glass, metal). */
  toon: boolean;
}

// v6.25.5: palette bumped +12% saturation, warmed slightly. Compare to the
// previous flat values; these read warmer in scene without needing textures.
const MATERIAL_PALETTE: Record<string, PaletteEntry> = {
  marble:    { color: 0xefe8cc, roughness: 0.30, metalness: 0.00, toon: true  },
  concrete:  { color: 0xa6a298, roughness: 0.85, metalness: 0.05, toon: true  },
  wood:      { color: 0x8a5a32, roughness: 0.70, metalness: 0.00, toon: true  },
  brick:     { color: 0xb86346, roughness: 0.80, metalness: 0.00, toon: true  },
  stone:     { color: 0x968d7c, roughness: 0.75, metalness: 0.00, toon: true  },
  glass:     { color: 0xc8e6f0, roughness: 0.05, metalness: 0.00, toon: false },
  steel:     { color: 0xb6b9be, roughness: 0.30, metalness: 0.90, toon: false },
  gold:      { color: 0xe2bc6a, roughness: 0.25, metalness: 0.95, toon: false },
  copper:    { color: 0xd28858, roughness: 0.45, metalness: 0.85, toon: false },
  // default — used when no material modifier is present
  _default:  { color: 0xc6b294, roughness: 0.60, metalness: 0.05, toon: true  },
};

// Named clothing colors from wearableCreator's COLOR_PALETTE. A wearable
// modifier like 'scarlet' tints the resolved material toward this hex. These
// are checked AFTER the material-type lookup, so a wearable picks up its
// material (e.g. wool/silk) for shading + this color override for the tint.
const COLOR_NAME_MAP: Record<string, number> = {
  scarlet:  0xd23a2e,
  azure:    0x3a7bd2,
  emerald:  0x2ea36a,
  ivory:    0xefe8cc,
  obsidian: 0x23212a,
  umber:    0x6b4423,
  mustard:  0xd2a72e,
  violet:   0x7a4fb5,
  teal:     0x2e9aa3,
  rose:     0xe07a96,
};

const CONDITION_TINT: Record<string, { darken: number; rough_add: number }> = {
  weathered:   { darken: 0.85, rough_add: 0.10 },
  ruined:      { darken: 0.70, rough_add: 0.20 },
  half_ruined: { darken: 0.78, rough_add: 0.15 },
  overgrown:   { darken: 0.80, rough_add: 0.05 },
  abandoned:   { darken: 0.85, rough_add: 0.10 },
  pristine:    { darken: 1.00, rough_add: -0.05 },
  polished:    { darken: 1.05, rough_add: -0.15 },
};

// Shared 4-band toon gradient ramp. One allocation per session; reused by
// every MeshToonMaterial. Without an explicit gradientMap MeshToonMaterial
// falls back to a smooth ramp (looks closer to MeshStandard), so this is
// what gives us the actual posterized look.
let _toonGradient: THREE.DataTexture | null = null;
function getToonGradient(): THREE.DataTexture {
  if (_toonGradient) return _toonGradient;
  // 4 stops of luminance: deep shadow / mid shadow / lit / hot
  const data = new Uint8Array([56, 56, 56, 255,  140, 140, 140, 255,  210, 210, 210, 255,  255, 255, 255, 255]);
  const tex = new THREE.DataTexture(data, 4, 1, THREE.RGBAFormat);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  _toonGradient = tex;
  return tex;
}

export function materialFor(modifiers: string[] = []): THREE.Material {
  // Pick the first material modifier present; default if none
  let palette = MATERIAL_PALETTE._default;
  for (const m of modifiers) {
    if (m in MATERIAL_PALETTE) {
      palette = MATERIAL_PALETTE[m];
      break;
    }
  }

  let { color, roughness, metalness, toon } = palette;

  // Named-color override (clothing): a 'scarlet' / 'azure' / etc. modifier
  // replaces the base color so the wearable reads as that color. First match
  // wins. Applied after the material-type pick so material still governs
  // toon/roughness/metalness; condition tints below still darken on top.
  for (const m of modifiers) {
    if (m in COLOR_NAME_MAP) {
      color = COLOR_NAME_MAP[m];
      break;
    }
  }

  for (const m of modifiers) {
    if (m in CONDITION_TINT) {
      const t = CONDITION_TINT[m];
      const c = new THREE.Color(color);
      c.multiplyScalar(t.darken);
      color = c.getHex();
      roughness = Math.max(0, Math.min(1, roughness + t.rough_add));
    }
  }

  // Soft-clay restyle: matte smooth standard instead of banded toon, matching
  // materialRegistry's CLAY_MODE so all generator content reads as one clay world.
  // Toon (opaque construction) surfaces get the deepening pass: per-material
  // roughness jitter (seeded by colour) + the shared thumbprint normal map.
  // Metals/glass keep their identity (just calmed) and skip the clay normal.
  if (CLAY_MODE) {
    if (toon) {
      const _clayM = new THREE.MeshStandardMaterial({
        color: new THREE.Color(color),
        roughness: clayRoughness(Math.max(0.9, roughness), color),
        metalness: 0,
        normalMap: getClayNormalMap(),
        normalScale: clayNormalScale(),
        envMapIntensity: 0.5,
      });
      applyClayShaderPatch(_clayM);   // whisper wax-fresnel rim
      return _clayM;
    }
    return new THREE.MeshStandardMaterial({
      color: new THREE.Color(color),
      roughness: Math.min(1, roughness + 0.15),
      metalness: metalness * 0.85,
      envMapIntensity: 0.5,
    });
  }
  if (toon) {
    return new THREE.MeshToonMaterial({
      color: new THREE.Color(color),
      gradientMap: getToonGradient(),
    });
  }
  return new THREE.MeshStandardMaterial({
    color: new THREE.Color(color),
    roughness,
    metalness,
  });
}

/** Resolve the normal Wander material, then apply a catalogue-authored tint. */
export function materialForTint(modifiers: string[] = [], tint?: unknown): THREE.Material {
  const mat = materialFor(modifiers);
  const hasTint = typeof tint === "string" || typeof tint === "number";
  try {
    const color = hasTint ? new THREE.Color(tint as THREE.ColorRepresentation) : null;
    const target = (mat as THREE.Material & {
      color?: THREE.Color;
      emissive?: THREE.Color;
      emissiveIntensity?: number;
    });
    if (color && target.color) target.color.copy(color);
    if (modifiers.includes("interior-glow") && target.emissive) {
      target.emissive.copy(color || new THREE.Color(0xffc86a));
      target.emissiveIntensity = 0.75;
    }
  } catch {}
  return mat;
}
