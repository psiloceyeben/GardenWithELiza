// Slot-local procedural clothing and equipment visuals.
import * as THREE from "three";
import type { AtomNode } from "../../shared/opTree";
import { materialFor } from "./materials";
import { stampHitVectors, inferMaterialTag, type HitVector } from "../hitbox";

export function wearableSlot(profile: string): string {
  return ({
    glasses: "face", mask: "face", helm: "head", head: "head", hat: "head",
    boots: "feet", feet: "feet", ring: "hand_right", amulet: "neck", scarf: "neck",
    cape: "back", backpack: "back", cloak: "torso", robe: "torso", armor: "torso",
    shirt: "torso", jacket: "torso", tunic: "torso", skirt: "torso", belt: "torso",
  } as Record<string, string>)[profile] || "torso";
}

export function generateWearable(node: AtomNode): THREE.Object3D {
  const profile = String(node.params?.profile || "cloak");
  const group = new THREE.Group();
  const mat = materialFor(node.modifiers || []);
  const add = (mesh: THREE.Mesh) => { mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh); return mesh; };

  if (profile === "glasses") {
    for (const x of [-0.1, 0.1]) add(new THREE.Mesh(new THREE.TorusGeometry(0.08, 0.012, 8, 16), mat)).position.set(x, 0, 0.02);
    const bridge = add(new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.06, 8), mat));
    bridge.position.z = 0.02; bridge.rotation.z = Math.PI / 2;
  } else if (profile === "mask") {
    const mask = add(new THREE.Mesh(new THREE.SphereGeometry(0.19, 16, 10, 0, Math.PI * 2, 0.45, Math.PI * 0.45), mat));
    mask.position.set(0, -0.03, 0.005); mask.scale.set(1, 1.05, 0.35);
  } else if (profile === "hat") {
    add(new THREE.Mesh(new THREE.CylinderGeometry(0.29, 0.29, 0.035, 18), mat));
    const crown = add(new THREE.Mesh(new THREE.ConeGeometry(0.17, 0.36, 16), mat)); crown.position.y = 0.19;
  } else if (profile === "helm" || profile === "head") {
    const helm = add(new THREE.Mesh(new THREE.SphereGeometry(0.21, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.72), mat));
    helm.position.y = -0.1;
  } else if (profile === "boots" || profile === "feet") {
    for (const x of [-0.13, 0.13]) add(new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.13, 0.27), mat)).position.set(x, 0.04, 0.04);
  } else if (profile === "ring") {
    add(new THREE.Mesh(new THREE.TorusGeometry(0.04, 0.008, 8, 16), mat));
  } else if (profile === "amulet") {
    const chain = add(new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.005, 6, 24), mat)); chain.position.set(0, -0.06, 0.03);
    const pendant = add(new THREE.Mesh(new THREE.SphereGeometry(0.03, 12, 8), mat)); pendant.position.set(0, -0.19, 0.06);
  } else if (profile === "scarf") {
    const loop = add(new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.035, 8, 20), mat)); loop.rotation.x = Math.PI / 2;
    const tail = add(new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.42, 0.035), mat)); tail.position.set(0.06, -0.23, -0.02); tail.rotation.z = -0.12;
  } else if (profile === "cape") {
    const cape = add(new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.98, 0.045), mat)); cape.position.set(0, -0.22, -0.02); cape.rotation.x = -0.08;
    const clasp = add(new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.018, 8, 18), mat)); clasp.position.set(0, 0.25, 0.04);
  } else if (profile === "backpack") {
    const pack = add(new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.60, 0.22), mat)); pack.position.set(0, -0.05, -0.08);
  } else if (profile === "belt") {
    const belt = add(new THREE.Mesh(new THREE.TorusGeometry(0.31, 0.035, 8, 24), mat)); belt.rotation.x = Math.PI / 2; belt.scale.z = 0.88;
    const buckle = add(new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.09, 0.04), mat)); buckle.position.set(0, 0, 0.28);
  } else if (profile === "skirt") {
    const skirt = add(new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.42, 0.75, 14), mat)); skirt.position.y = -0.42;
  } else {
    const top = profile === "shirt" ? 0.30 : profile === "jacket" ? 0.33 : 0.29;
    const bottom = profile === "armor" ? 0.36 : profile === "robe" || profile === "cloak" ? 0.42 : 0.34;
    const height = profile === "robe" || profile === "cloak" ? 1.08 : profile === "tunic" ? 0.78 : 0.67;
    const torso = add(new THREE.Mesh(new THREE.CylinderGeometry(top, bottom, height, 12), mat));
    torso.position.y = profile === "robe" || profile === "cloak" ? -0.22 : -0.02;
    if (profile === "armor" || profile === "jacket") for (const side of [-1, 1]) {
      const shoulder = add(new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8), mat));
      shoulder.position.set(side * 0.32, 0.22, 0); shoulder.scale.set(1.2, 0.75, 1);
    }
  }

  const slot = String(node.params?.attach_slot || wearableSlot(profile));
  const hits: HitVector[] = [{
    label: profile,
    region: { center: [0, 0, 0], half_size: [0.35, 0.55, 0.24] },
    material_tag: inferMaterialTag(node.modifiers || []),
    affordances: { grasp: true, grasp_handle: [0, 0, 0], weight_class: 1, detach_cost: 0.5, inscribe: true, attach_to: [`player.slot.${slot}`, "wearable.rack"] },
  }];
  stampHitVectors(group, hits);
  return group;
}
