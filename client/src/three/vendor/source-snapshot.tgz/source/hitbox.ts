// Vectorized hitboxes — surface-region affordances per the substrate paradigm.
//
// A hitbox is NOT a single AABB; it's a vector field over the object's
// surface where each region carries the affordances inherited from the
// op-tree node that produced it. A column has three regions: base
// (graspable, mountable), shaft (climb-able, lean-able), capital
// (graspable handle, mountable). A wall has: face (paint/inscribe-able),
// top (walk-on if thick enough, mount-able), bottom-edge (sit-on if
// flat). A roof has: outer face (slippery), peak (graspable seam),
// underside (shelter).
//
// Each verb in the game ("sit on", "lean against", "inscribe", "cut",
// "burn") becomes a function that filters the hit-vector field of the
// nearest entity for vectors with the required affordance and dispatches
// the appropriate action. Adding a new verb is therefore O(one-function),
// not O(rewrite-every-object).
//
// Composers emit SEAM hit-vectors at the join points between their children
// — these carry `detach_cost` which determines disassembly difficulty. A
// fresh build has high detach_cost (well-fitted); a `ruined` build has low
// detach_cost (already coming apart).

import * as THREE from "three";

export interface Affordances {
  /** Player can grab / pick this region up. */
  grasp?: boolean;
  /** Preferred grasp anchor (object-local). */
  grasp_handle?: [number, number, number];
  /** How heavy / hard to lift, 0=light → 10=immovable. */
  weight_class?: number;
  /** Cost to detach this region from its parent (1.0 = welded marble,
   *  0.0 = falls off when looked at). */
  detach_cost?: number;
  /** Op-tree kinds that can attach onto this region. */
  attach_to?: string[];
  /** Player can sit here. */
  sit_on?: boolean;
  /** Walkable horizontal surface. */
  walk_on?: boolean;
  /** Climbable vertical surface. */
  climb?: boolean;
  /** Inscribe-able / paintable / sign-mountable. */
  inscribe?: boolean;
  /** Liquid container (fountains, basins). */
  pour_into?: boolean;
  /** Light/sound shelter. */
  shelter?: boolean;
  /** Acoustic resonator (instruments, hollow drums). */
  resonate?: boolean;
}

export interface HitVector {
  /** Object-local surface region (oriented bounding box). */
  region: {
    center: [number, number, number];
    half_size: [number, number, number];
    /** Optional rotation Euler-Y in radians. */
    rotY?: number;
  };
  /** Which op-tree node ID produced this region (for disassembly). */
  origin_node?: string;
  /** Material classification: "marble" / "concrete" / "wood" / "iron"... */
  material_tag?: string;
  /** Affordance flags + scalars. */
  affordances: Affordances;
  /** Free-form region label for debugging ("base" / "shaft" / "capital"). */
  label?: string;
}

/** Stamp a Three.js object with hit-vectors. Stored on userData.hitVectors. */
export function stampHitVectors(obj: THREE.Object3D, vectors: HitVector[]): void {
  obj.userData.hitVectors = vectors;
}

/** Read the hit-vectors off an object (or empty list if none stamped). */
export function readHitVectors(obj: THREE.Object3D): HitVector[] {
  return obj.userData.hitVectors || [];
}

/** Filter hit-vectors by an affordance predicate (e.g. v => v.affordances.sit_on). */
export function filterByAffordance(
  vectors: HitVector[],
  pred: (v: HitVector) => boolean,
): HitVector[] {
  return vectors.filter(pred);
}

/** Convert a hit-vector region to a world-space Box3 by reading the obj transform. */
export function hitVectorWorldBox(
  obj: THREE.Object3D,
  hv: HitVector,
): THREE.Box3 {
  const cx = hv.region.center[0];
  const cy = hv.region.center[1];
  const cz = hv.region.center[2];
  const hx = hv.region.half_size[0];
  const hy = hv.region.half_size[1];
  const hz = hv.region.half_size[2];
  const local = new THREE.Box3(
    new THREE.Vector3(cx - hx, cy - hy, cz - hz),
    new THREE.Vector3(cx + hx, cy + hy, cz + hz),
  );
  // Transform local box corners to world via obj's matrixWorld
  obj.updateWorldMatrix(true, false);
  return local.applyMatrix4(obj.matrixWorld);
}

/** Material tag inference from the modifier list (mirrors materials.ts logic). */
export function inferMaterialTag(modifiers: string[] = []): string {
  for (const m of modifiers) {
    if (["marble", "concrete", "wood", "stone", "brick", "glass", "steel",
         "iron", "bronze", "gold"].includes(m)) return m;
  }
  return "stone";  // default
}

/** Detach-cost from the modifier list (ruined / weathered = easier to take apart). */
export function inferDetachCost(modifiers: string[] = []): number {
  if (modifiers.includes("ruined") || modifiers.includes("half_ruined")) return 0.15;
  if (modifiers.includes("weathered") || modifiers.includes("abandoned")) return 0.3;
  if (modifiers.includes("polished") || modifiers.includes("pristine")) return 0.95;
  return 0.6;  // typical
}
